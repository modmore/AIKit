<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2025 modmore

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '# AIKit

AI Toolkit for MODX 3.

AI Kit provides an AI Assistant in the MODX Manager that can answer questions, generate content, and more. It can be seamlessly integrated into MODX Extras providing more contextual assistance. Extras can either provide custom functions for the assistant to use, and/or invoke the assistant contextually.

After installing, please review the aikit system settings for all configuration that may be required.
',
    'changelog' => 'AIKit 0.1.0-pl
-----------------
Released on 2025-03-01

- First packaged release.

',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '95f3c6a232681b376f5f94d710acfc04',
      'native_key' => 'aikit',
      'filename' => 'MODX/Revolution/modNamespace/dd14e32a83553e8b9aefd8f1ce0f1881.vehicle',
      'namespace' => 'aikit',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '05dd1ac2d439b28e4f5a850838760e88',
      'native_key' => '05dd1ac2d439b28e4f5a850838760e88',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/236168fc05380faf74077c35800018e1.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '7d360b9cc21a8a42d8604b04615e1b15',
      'native_key' => '7d360b9cc21a8a42d8604b04615e1b15',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/1533b1559f9682ce897ffcb0db412523.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e3e092a1a0d321f2d60072d49ef7cbde',
      'native_key' => 'aikit.model',
      'filename' => 'MODX/Revolution/modSystemSetting/c1d6d761694033ee19a5e5c2597fc71c.vehicle',
      'namespace' => 'aikit',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1aead5b7eedd01ff90c4f99bf92252ed',
      'native_key' => 'aikit.system_prompt',
      'filename' => 'MODX/Revolution/modSystemSetting/873518789b38a10ed54b9df23177db15.vehicle',
      'namespace' => 'aikit',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0ea77fc2408927d6f5a987208d6c6da3',
      'native_key' => 'aikit.system_prompt_visible',
      'filename' => 'MODX/Revolution/modSystemSetting/b0553c453153caab7bcb594254fafc3f.vehicle',
      'namespace' => 'aikit',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'acc8b60fc3b5d93f809bbe22ec511b5c',
      'native_key' => 'aikit.openai_api_key',
      'filename' => 'MODX/Revolution/modSystemSetting/2bd397b16fdfa4d0d5a109a8ceec9425.vehicle',
      'namespace' => 'aikit',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f63281882fb6667c3a8274f8ce5308e9',
      'native_key' => 'aikit.openai_model',
      'filename' => 'MODX/Revolution/modSystemSetting/6801d506168fc38c1970f2b9e93cf2d2.vehicle',
      'namespace' => 'aikit',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f7036c5183a22baeedc0dc93ba04446e',
      'native_key' => 'aikit.openai_endpoint',
      'filename' => 'MODX/Revolution/modSystemSetting/1508098941adf297052082d8b8de2a7a.vehicle',
      'namespace' => 'aikit',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4bd51e3b45b8f0005a377f35b782fb58',
      'native_key' => 'aikit.vector_database',
      'filename' => 'MODX/Revolution/modSystemSetting/03917893055311d84d99b99a90a1b50e.vehicle',
      'namespace' => 'aikit',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '99cbc8968ea852fa7ff757291f62ce29',
      'native_key' => 'aikit.pinecone_endpoint',
      'filename' => 'MODX/Revolution/modSystemSetting/89dfdd8ea49e620a0b62920ff535ad89.vehicle',
      'namespace' => 'aikit',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3911824b5c32d8de0e9143951857de5f',
      'native_key' => 'aikit.pinecone_api_key',
      'filename' => 'MODX/Revolution/modSystemSetting/bc1bc3c2a60f33576691c9849eeba478.vehicle',
      'namespace' => 'aikit',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '15d558623beec88fc7d624ea6c4e88d3',
      'native_key' => 'aikit.pinecone_content_index',
      'filename' => 'MODX/Revolution/modSystemSetting/2ea96c55f089598e0af46b1cf8dacabf.vehicle',
      'namespace' => 'aikit',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '46892c5201e3ec659300721145d16345',
      'native_key' => 'aikit.configuration',
      'filename' => 'MODX/Revolution/modMenu/c3cacefb805bdb521ac21215bdfde0a8.vehicle',
      'namespace' => 'aikit',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '80fc3116fdb50e56d1732cb8b59e5e84',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/fb907e4a4aea4f5248a5534cd4e24f3b.vehicle',
      'namespace' => 'aikit',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modPlugin',
      'guid' => 'feaac3d7d859341a5fe8de40f98c14ba',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modPlugin/08b9383551a3638b6ee0a3e1cb3efe40.vehicle',
      'namespace' => 'aikit',
    ),
  ),
);