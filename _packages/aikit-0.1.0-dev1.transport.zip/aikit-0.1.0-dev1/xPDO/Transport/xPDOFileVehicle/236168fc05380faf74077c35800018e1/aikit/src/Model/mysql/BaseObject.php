<?php
namespace modmore\AIKit\Model\mysql;

use xPDO\xPDO;

class BaseObject extends \modmore\AIKit\Model\BaseObject
{

    public static $metaMap = array (
        'package' => 'modmore\\AIKit\\Model\\',
        'version' => '3.0',
        'extends' => 'xPDO\\Om\\xPDOSimpleObject',
        'tableMeta' => 
        array (
            'engine' => 'InnoDB',
        ),
        'fields' => 
        array (
        ),
        'fieldMeta' => 
        array (
        ),
    );

}
