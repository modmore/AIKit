<?php

$_lang['aikit_configuration'] = 'AI Kit Configuration';
