<?php
$xpdo_meta_map = array (
    'version' => '3.0',
    'namespace' => 'modmore\\AIKit\\Model',
    'namespacePrefix' => 'modmore\\AIKit',
    'class_map' => 
    array (
        'xPDO\\Om\\xPDOSimpleObject' => 
        array (
            0 => 'modmore\\AIKit\\Model\\BaseObject',
        ),
        'modmore\\AIKit\\Model\\BaseObject' => 
        array (
            0 => 'modmore\\AIKit\\Model\\Conversation',
            1 => 'modmore\\AIKit\\Model\\Message',
            2 => 'modmore\\AIKit\\Model\\Tool',
        ),
    ),
);