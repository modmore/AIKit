# AIKit

AI Toolkit for MODX 3.

AI Kit provides an AI Assistant in the MODX Manager that can answer questions, generate content, and more. It can be seamlessly integrated into MODX Extras providing more contextual assistance. Extras can either provide custom functions for the assistant to use, and/or invoke the assistant contextually.

After installing, please review the aikit system settings for all configuration that may be required.
