<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2025 modmore

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '# AIKit

AI Toolkit for MODX 3.

AI Kit provides an AI Assistant in the MODX Manager that can answer questions, generate content, and more. It can be seamlessly integrated into MODX Extras providing more contextual assistance. Extras can either provide custom functions for the assistant to use, and/or invoke the assistant contextually.

After installing, please review the aikit system settings for all configuration that may be required.
',
    'changelog' => 'AIKit 0.1.0-pl
-----------------
Released on 2025-03-01

- First packaged release.

',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '1aa4e12c963ca5b8556d4ecd87405d9d',
      'native_key' => 'aikit',
      'filename' => 'MODX/Revolution/modNamespace/2bc52a0a13a52a697a8aa729cca37fc7.vehicle',
      'namespace' => 'aikit',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'a8e88c58fe1ed48e5edb2c9a44000a1b',
      'native_key' => 'a8e88c58fe1ed48e5edb2c9a44000a1b',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/76ab16949cfccc668f4c99b517b1bf43.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'd6426c31a7995bc8801359a802709c53',
      'native_key' => 'd6426c31a7995bc8801359a802709c53',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/ed223074974f8b7e92fc18f6c92a744c.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c62fabe63732bbdc6dde8a10ca644d6e',
      'native_key' => 'aikit.model',
      'filename' => 'MODX/Revolution/modSystemSetting/2f0342d56fbc1fa992283d2b43e3b30a.vehicle',
      'namespace' => 'aikit',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a3465f208755905880ba18d0a85a52d7',
      'native_key' => 'aikit.system_prompt',
      'filename' => 'MODX/Revolution/modSystemSetting/65ae8758578880a5f994869496b00750.vehicle',
      'namespace' => 'aikit',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '32a7f6ea67431f8e01554bb271eea3f9',
      'native_key' => 'aikit.system_prompt_visible',
      'filename' => 'MODX/Revolution/modSystemSetting/fd227a07f7a7446ccd3238078b19c53f.vehicle',
      'namespace' => 'aikit',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '912536a3e7def18f2e4e4974e29298c9',
      'native_key' => 'aikit.openai_api_key',
      'filename' => 'MODX/Revolution/modSystemSetting/afbd59203dfbc79f7c0cb8701bca4709.vehicle',
      'namespace' => 'aikit',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9a05b121d1a15bdf716a058f38196856',
      'native_key' => 'aikit.openai_model',
      'filename' => 'MODX/Revolution/modSystemSetting/9d1ce5f2499ec3b54efc8ba25b8217ad.vehicle',
      'namespace' => 'aikit',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd515bcb1bdf77ff37f6a079eed320aea',
      'native_key' => 'aikit.openai_endpoint',
      'filename' => 'MODX/Revolution/modSystemSetting/b7ea81a2b690ddd1d7e3a3f455a1fa97.vehicle',
      'namespace' => 'aikit',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '57099d696581f22ef1653eda7245afc3',
      'native_key' => 'aikit.vector_database',
      'filename' => 'MODX/Revolution/modSystemSetting/58d8dcdc7b1e8f9d940a72d77b698271.vehicle',
      'namespace' => 'aikit',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3241f301c69037b77473fa0d527da02d',
      'native_key' => 'aikit.pinecone_endpoint',
      'filename' => 'MODX/Revolution/modSystemSetting/262607ebe51ca423529cc86b8844eba2.vehicle',
      'namespace' => 'aikit',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b7f96f860f9eb5ebbe3fa5480d5f8022',
      'native_key' => 'aikit.pinecone_api_key',
      'filename' => 'MODX/Revolution/modSystemSetting/5bfb9fedfda6ffcf6a4a0175962127a8.vehicle',
      'namespace' => 'aikit',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9cc799382551c4e6e6f052cb02024d40',
      'native_key' => 'aikit.pinecone_content_index',
      'filename' => 'MODX/Revolution/modSystemSetting/8535aeeea5ecd9bda8c7c71f423fecb8.vehicle',
      'namespace' => 'aikit',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '1702a6e2031c97318e0fecb4a16ae5b7',
      'native_key' => 'aikit.configuration',
      'filename' => 'MODX/Revolution/modMenu/834edf613081a25d2207bd31ec9deb55.vehicle',
      'namespace' => 'aikit',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '5abdc9a5839fdeb1265db7f23d0750ad',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/12e7cf20049d7cff057baa0a069b5905.vehicle',
      'namespace' => 'aikit',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modPlugin',
      'guid' => '6e414f8582cbf0c528fcbdd798a0a695',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modPlugin/bc0c982c2b0551bb9fa156d1c0e0bc7a.vehicle',
      'namespace' => 'aikit',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSnippet',
      'guid' => 'd8de2a4cf4620ad7e77abf9bb609383b',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modSnippet/46ebd141eee015dc05fb7de09d56b626.vehicle',
      'namespace' => 'aikit',
    ),
  ),
);