<?php

$_lang['aikit'] = 'AI Kit';
$_lang['aikit.configuration'] = 'AI Kit configuration';
