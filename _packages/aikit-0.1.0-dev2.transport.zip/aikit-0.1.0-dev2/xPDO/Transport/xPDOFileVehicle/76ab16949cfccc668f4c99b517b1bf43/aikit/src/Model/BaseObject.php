<?php
namespace modmore\AIKit\Model;

use xPDO\xPDO;

/**
 * Class BaseObject
 *
 *
 * @package modmore\AIKit\Model
 */
class BaseObject extends \xPDO\Om\xPDOSimpleObject
{
}
